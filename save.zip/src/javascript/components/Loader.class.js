class Loader {

  constructor(options) {
    // this.loader = new PIXI.Loader()

    // STORAGE.loaderClass = this
    // STORAGE.loader = this.loader
  }

}

export default Loader
