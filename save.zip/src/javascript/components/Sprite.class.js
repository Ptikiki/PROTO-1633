const PIXI = require('pixi.js')
console.log(PIXI)

class Sprite {

  constructor(options) {
    STORAGE.spriteClass = this
    STORAGE.state
    STORAGE.loader = new PIXI.Loader()
    STORAGE.loader.add("assets/sprites/sprites.json").load(this.setup)
  }

  setup() {
    let sheet = STORAGE.loader.resources["assets/sprites/sprites.json"].spritesheet
    STORAGE.female = new PIXI.Sprite(sheet.textures["land0.png"])
    console.log(STORAGE.female)

    STORAGE.animatedFemale = new PIXI.AnimatedSprite(sheet.animations["land"])

    STORAGE.animatedFemale.play()
    STORAGE.app.stage.addChild(STORAGE.animatedFemale)
    // STORAGE.animatedFemale.transform.position._x = 100
    // STORAGE.animatedFemale.transform.position._y = 100
    console.log(STORAGE.animatedFemale)


    let left = STORAGE.spriteClass.keyboard("ArrowLeft"),
      up = STORAGE.spriteClass.keyboard("ArrowUp"),
      right = STORAGE.spriteClass.keyboard("ArrowRight"),
      down = STORAGE.spriteClass.keyboard("ArrowDown")

    left.press = () => {
      console.log("gauche")
      STORAGE.vx = -5
      STORAGE.vy = 0
    }
    left.release = () => {
      if (!right.isDown && STORAGE.vy === 0) {
        STORAGE.vx = 0
      }
    }

    right.press = () => {
      console.log("droite")
      STORAGE.vx = 100
      STORAGE.vy = 0
    }
    right.release = () => {
      if (!left.isDown && STORAGE.vy === 0) {
        STORAGE.vx = 0
      }
    }

    STORAGE.spriteClass.state = STORAGE.spriteClass.play
    STORAGE.app.ticker.add(delta => STORAGE.spriteClass.gameLoop(delta))
  }

  gameLoop(delta){
    STORAGE.spriteClass.state(delta)
  }

  play(delta) {
    STORAGE.animatedFemale.x += 0.5
    console.log(STORAGE.vx)
    //STORAGE.animatedFemale.x += STORAGE.vx
    //STORAGE.animatedFemale.y += STORAGE.animatedFemale.vy
    //console.log(STORAGE.animatedFemale)
  }

  keyboard(value) {
    let key = {}
    key.value = value
    key.isDown = false
    key.isUp = true
    key.press = undefined
    key.release = undefined

    key.downHandler = event => {
      if (event.key === key.value) {
        if (key.isUp && key.press) key.press()
        key.isDown = true
        key.isUp = false
        event.preventDefault()
      }
    }

    key.upHandler = event => {
      if (event.key === key.value) {
        if (key.isDown && key.release) key.release()
        key.isDown = false
        key.isUp = true
        event.preventDefault()
      }
    }

    const downListener = key.downHandler.bind(key)
    const upListener = key.upHandler.bind(key)
    
    window.addEventListener(
      "keydown", downListener, false
    )
    window.addEventListener(
      "keyup", upListener, false
    )
    
    key.unsubscribe = () => {
      window.removeEventListener("keydown", downListener)
      window.removeEventListener("keyup", upListener)
    }
    
    return key
  }
}

export default Sprite
